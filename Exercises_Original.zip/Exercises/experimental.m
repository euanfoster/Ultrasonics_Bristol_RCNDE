clear; %clear all variables from memory
close all; %close all windows
clc; %clear command window

disp('Frequency dependent attenuation of perspex'); %display the title

%INPUTS

%file name
fname = '7_8mm_thick_perspex.mat';
sample_thickness = 7.8e-3;

%PROGRAM

%load file
load(fname);

%plot the data supplied
plot(time * 1e6, voltage);
xlabel('Time (\mus)');
ylabel('Voltage (V)');

%write your own code here to determine the frequency-dependent attenuation
%of perspex from the data supplied

