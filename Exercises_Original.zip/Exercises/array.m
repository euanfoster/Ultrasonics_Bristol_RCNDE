clear; close all; clc; 

%In this exercise, you will use a pre-written function, fn_simulate_data_v2,
%to synthesise the FMC data from a specified ultrasonic array when
%looking at various samples.

%Your task is to specify an appropriate array, centre frequency and write
%the necessary code to convert the FMC data into an image. The
%ultimate goal is to obtain and analyse the image when
%fn_simulate_data is used with code = 'XXX' where 'XXX' is your initials.
%The sample in this case contains a number of cracks and point reflectors
%in various patterns, including 2 digits.

%When you formed an image of this sample, you should consider questions
%such as:
% - Can you resolve the most closely-spaced point reflectors? How do you
% assess this?
% - Can you estimate the lengths of the cracks from the image? If so, how?
% - Can you tell what digits are present?
% - What is the smallest number of elements needed in an array to obtain
% adequate images?

%The region of interest in all samples is from x = -20 to 20 mm and from 
%z = 10 to 90 mm, but you will probably want to create a slightly larger 
%image. The speed of sound in the target is 5000 m/s.

%The parameters 'no_elements', 'element_pitch', 'el_width' and 
%'centre_freq' describe the array and should be in SI units (i.e. m, Hz). 
%The array has to satisfy the following manufacturing limits:
% - maximum number of elements: 128
% - minimum element width: 0.1 mm
% - maximum element width: 4.0 mm
% - minimum gap between elements: 0.05 mm (i.e. element_pitch - el_width >=
%   0.05mm).
% - centre frequency must be in the range 1 to 10 MHz

%For the 'sample' parameter use either:
% - 'TEST POINTS' to return the FMC data from a sample with 5 point targets 
%   across the region of interest with no noise present
% - 'TEST CRACK' to return the FMC data from a sample with a 5mm long crack
%   in the centre of the region of interest with no noise present
% - 'TEST NUMBERS' to return the FMC data for a sample containing point 
%   targets representing the digits 1-9 in the region of interest with no 
%   noise present
% - 'XXX' where 'XXX' is your initials to return the FMC data for the 
%   blind trial sample containing various cracks, point reflectors and noise.
%   Adding '+NOISE' to any of the first three sample strings (e.g. 
%   'TEST POINTS+NOISE') will return the same FMC data with additional 
%   noise at the same level as the noise for the blind trial sample. 

%Your chosen array parameters go here:
no_elements = 32; 
element_pitch = 1.0e-3;
element_width = 0.9e-3; 
centre_freq = 2e6;

%set code to the appropriate code for the sample for which you wish to simulate data
sample = 'TEST POINTS';

%Call the encrypted function to simulate the FMC data
[time, time_data, element_positions] = fn_simulate_data(sample, no_elements, element_pitch, element_width, centre_freq);

%The fn_simulate_data function returns the following parameters:
% - 'time' is an m-by-1 column vector representing the time-axis of every 
%   A-scan in the FMC data
% - 'time_data' is a m-by-no_elements-by-no_elements 3D array containing 
%   the FMC data itself. The dimensions represent time, transmitter number 
%   and receiver number. Therefore time_data(:, 7, 3)) is the A-scan for 
%   transmitter element 7 and receiver element 3.
% - 'element_positions' is a 1-by-no_elements row-vector of array element 
%   x-coordinates, centred on x = 0. Therefore in the example case of 
%   time_data(:, 7, 3), the transmitting element is at element_positions(7)
%   and the receiving element is at element_positions(3).

%Example of a simulated A-scan from the FMC data
figure;
transmitter_index = 7; %this is just an arbitrary choice as an example
receiver_index = 3; %this is just an arbitrary choice as an example
plot(time, time_data(:, transmitter_index, receiver_index));
title(sprintf('Time signal for transmitter %i to receiver %i', transmitter_index, receiver_index));
xlabel('Time (s)');

%Now write your own code to convert this data into an image ...
