clear; %clear all variables from memory
close all; %close all windows
clc; %clear command window

disp('Wave Animation 1'); %display the title

%INPUTS

%wave parameters
frequency = 1e6;
velocity = 3e3;

%x parameters
x_end = %TO BE ENTERED%
x_step = %TO BE ENTERED%

%time parameters
t_step = %TO BE ENTERED%
t_points = %TO BE ENTERED%

%PROGRAM

x = [0 : x_step : x_end]; %make a vector of x positions
t = [0 : t_step : t_step * t_points]; %make a vector of times

%calculate w and k from inputs
w = %TO BE ENTERED%
k = %TO BE ENTERED%

figure; %open a new graphics figure

%the animation loop follows
for ii = 1 : length(t)
    p = %TO BE ENTERED%
    clf; %clear the figure
    plot(x, p, 'b'); %plot u vs. x in blue
    pause(0.01); %pause for 1/100th of a second to allow plotting
end;

