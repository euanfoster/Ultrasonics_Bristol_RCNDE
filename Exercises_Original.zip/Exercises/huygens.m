clear; %clear all variables from memory
close all; %close all windows
clc; %clear command window

disp('Beam profile of a 2D transducer'); %display the title

%INPUTS

%wave parameters
velocity = 6e3;
frequency = 1e6;

%transducer details
transducer_width = 20e-3;
min_sources_per_wavelength = 5;

grid_size = 100e-3;
grid_pts = 100;

%PROGRAM

%set up output grid
x = %TO BE ENTERED
y = %TO BE ENTERED

%set up sources for transducer
source_x_positions = %TO BE ENTERED

%prepare output matrix
p = %TO BE ENTERED

tic
%INSERT LINES FOR THE MAIN CALCULATION HERE



%FINISH OF MAIN CALCUALTION
toc

%plot field
