clear; %clear all variables from memory
close all; %close all windows
clc; %clear command window

disp('Frequency domain'); %display the title

%INPUTS

%pulse parameters
number_cycles = 5; %keep
centre_frequency = 1e6; %keep

%wave propagation
nondispersive_propagation = 1; %keep
velocity_at_centre_frequency = 3e3; %keep

%time
time_step = %TO BE ENTERED
max_time = %TO BE ENTERED

%distance
distance_step = %TO BE ENTERED
max_distance = 150e-3; %keep

%PROGRAM

%create time vector
time = %TO BE ENTERED

%create distance vector
distance = %TO BE ENTERED

%create Hanning windowed toneburst
time_at_centre_of_pulse = %TO BE ENTERED

window = %TO BE ENTERED
sine_wave = %TO BE ENTERED

input_signal = window(:) .* sine_wave(:); %keep

%At this point the input time-domain signal should have been created

%calculate the frequency spectrum of the input pulse
fft_pts = %TO BE ENTERED
spectrum = %TO BE ENTERED
spectrum = %TO BE ENTERED

%build frequency axis
freq_step = %TO BE ENTERED
freq = %TO BE ENTERED

%At this point the frequency spectrum of the input time signal should have been created

if nondispersive_propagation 
    velocity = velocity_at_centre_frequency; %keep
else
    velocity = %TO BE ENTERED
end;

%create a vector of wavenumbers
k = %TO BE ENTERED

%prepate a matrix to put the results in
p = %TO BE ENTERED

%loop through the different distances and create the time-domain signal at
%each one and out into the matrix p
for ii = %TO BE ENTERED
    delayed_spectrum = %TO BE ENTERED
    %MORE LINES TO BE ENTERED!
end;

figure;
%ANIMATION LOOP TO BE ENTERED!
